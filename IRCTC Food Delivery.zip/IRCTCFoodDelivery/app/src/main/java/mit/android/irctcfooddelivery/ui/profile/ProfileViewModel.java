package mit.android.irctcfooddelivery.ui.profile;

import androidx.lifecycle.ViewModel;

public class ProfileViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
